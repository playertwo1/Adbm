# Android Premium Craft

**Skill para agentes de IA projetarem, construírem, criticarem e verificarem interfaces Android em padrão premium e pronto para release** - funciona no Claude Code, Codex, Antigravity/Gemini CLI e em qualquer agente que leia `SKILL.md`.

[English](README.md)

## Por que existe

Agentes geram UI Android que compila, mas parece com todo app gerado por IA: roxo padrão do Material, card dentro de card, banner "Bem-vindo de volta", legenda de 10sp, nenhum estado de erro, e "ficou ótimo!" sem nunca ter olhado um pixel. Esta skill dá ao agente **decisões** (direções visuais nomeadas e tokens de design), **conhecimento de ofício** (Material 3 / Expressive, layout, telas grandes, acessibilidade, motion, texto, estados) e **ferramentas para conferir o próprio trabalho** (lint com 39 regras, contraste da paleta, captura em matriz de dispositivos e um gate de release honesto).

## Instalação rápida

```powershell
py .\skills\android-premium-craft\scripts\install_skill.py --project "C:\CAMINHO\SEU-APP" --agents claude codex antigravity
```
Depois cole `skills/android-premium-craft/assets/AGENTS_SNIPPET.md` no `AGENTS.md`/`CLAUDE.md` do app, para as regras principais valerem mesmo quando a skill não for carregada.

Como plugin (depois de publicar no GitHub, trocando `OWNER` pelo seu usuário):
```text
/plugin marketplace add OWNER/android-premium-craft
/plugin install android-premium-craft@android-premium-craft
```

## Primeiro uso recomendado

1. `/android-premium-craft critique` na tela principal - sem editar código.
2. `/android-premium-craft shape` - brief, direção visual (âncora) e tokens antes de codar.
3. `/android-premium-craft redesign` - só a tela aprovada.
4. `/android-premium-craft see` e `matrix` - renderizar/capturar e se autocriticar.
5. `/android-premium-craft release-review` - PASS/FAIL/NOT RUN por checagem, com `review_gate.py`.

## Ferramentas locais

| Script | Uso | Altera o app? |
|---|---|---|
| `project_probe.py` | Versões, toolkit, flags do manifest, obrigações por targetSdk | Não |
| `ui_audit.py lint` | 39 regras de ofício (Markdown/JSON/SARIF) | Não |
| `ui_audit.py palette` | Contraste WCAG de todos os pares de papéis do tema | Não |
| `ui_audit.py contrast` | Contraste com cor translúcida (#AARRGGBB) | Não |
| `device_matrix.py` | Captura a tela em escuro, 200% de fonte, RTL, paisagem, navegação... | Muda configurações do aparelho temporariamente e restaura |
| `review_gate.py` | Valida o relatório de evidências e calcula a decisão | Não |
| `validate_skill.py` | Autochecagem da skill contra a especificação Agent Skills | Não |

Os testes (`py -m unittest discover -s tests -v`) cobrem os scripts; eles não testam o seu app.

Veja [IMPROVEMENTS.md](IMPROVEMENTS.md) para o diagnóstico da v1.2 e tudo o que mudou na v2.
