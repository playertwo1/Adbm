# Android Premium Craft

**An agent skill for designing, building, critiquing and verifying Android interfaces to a premium, release-ready standard** - for Claude Code, Codex, Antigravity/Gemini CLI and any agent that reads `SKILL.md`.

[Português (Brasil)](README.pt-BR.md)

Agents write Android UI that compiles but looks like every other generated app: baseline purple, cards in cards, a greeting banner, 10sp captions, no error states, and "looks great!" without ever seeing a pixel. This skill gives the agent **decisions** (named visual directions and design tokens), **craft knowledge** (Material 3 / Expressive, layout, adaptive, accessibility, motion, copy, states) and **tools to check its own work** (a 39-rule lint, palette contrast, a device-matrix capture, an honest release gate).

## What makes it different

| | |
|---|---|
| **Direction before pixels** | 10 named aesthetic anchors (Tonal Calm, Precision Pro, Expressive Material, Editorial...) with full recipes, plus an Android anti-slop list. |
| **A real design system** | Color roles, contrast levels, type scale, shape/space/elevation tokens, a ready `CraftTheme.kt` that passes its own contrast check. |
| **Current platform rules** | Edge-to-edge enforcement, predictive back at SDK 36, large-screen orientation/resizability at SDK 36/37, Material 3 Expressive version gates. |
| **The agent sees its work** | Visual feedback loop via Compose previews, adb or Maestro; `device_matrix.py` captures dark, 200% text, RTL, landscape, 3-button nav... and restores the device. |
| **Deterministic checks** | `ui_audit.py lint` (39 rules, Markdown/JSON/SARIF), `palette` (WCAG on every role pair), `contrast` (alpha compositing), `project_probe.py` (versions + mandates). |
| **Honest evidence** | Every claim is observed / verified-in-code / measured / automated-pass / not-run. No invented FPS or scores. `review_gate.py` derives the release decision. |
| **Plays well with Google's official skills** | Hands off to `edge-to-edge`, `adaptive`, `jetpack-compose-performance`, `navigation-3`, `styles`, Wear/TV/XR skills instead of duplicating them. |
| **Measured, not asserted** | `evals/` scenarios (with/without-skill protocol), 42 unit tests, CI, a self-validator for the Agent Skills spec. |

## Install

**Claude Code (plugin)**
```text
/plugin marketplace add OWNER/android-premium-craft
/plugin install android-premium-craft@android-premium-craft
```

**Codex (plugin)**
```text
codex plugin marketplace add OWNER/android-premium-craft
codex plugin add android-premium-craft@android-premium-craft
```

**Any agent, into one project**
```bash
python skills/android-premium-craft/scripts/install_skill.py --project /path/to/app --agents claude codex antigravity
```
Then paste `skills/android-premium-craft/assets/AGENTS_SNIPPET.md` into the app's `AGENTS.md`/`CLAUDE.md` so the core rules apply even when the skill is not loaded.

## Use

```text
/android-premium-craft critique the home screen
/android-premium-craft shape a dashboard for small-business cash flow
/android-premium-craft redesign settings following DESIGN.md
/android-premium-craft see            # render or capture, then self-critique
/android-premium-craft release-review
```
24 modes: `critique` (default), `shape`, `system`, `build`, `redesign`, `polish`, `bolder`, `quieter`, `distill`, `touch`, `space`, `adapt`, `animate`, `copy`, `harden`, `accessibility`, `audit`, `see`, `matrix`, `visual-regression`, `performance`, `reference`/`motion-study`, `release-review`.

## Tools (Python 3.9+, stdlib only, read-only on your app)

```bash
cd skills/android-premium-craft
python scripts/project_probe.py /path/to/app
python scripts/ui_audit.py lint /path/to/app --format sarif > craft.sarif   # GitHub code scanning
python scripts/ui_audit.py palette /path/to/app
python scripts/device_matrix.py --out shots/ --profiles core --package com.example --dry-run
python scripts/review_gate.py evidence.json --require-ready
python -m unittest discover -s tests -v
```

## Structure

```
skills/android-premium-craft/
  SKILL.md                 router: principles, craft loop, modes, module index
  modules/01-discover ... 11-agents   30 focused modules (load only what a mode needs)
  research/                evidence ledger and dated sources
  assets/                  DESIGN.md template, evidence JSON, AGENTS snippet, Compose templates
  scripts/                 probe, lint/palette/contrast, device matrix, gate, installer, validator
  evals/                   scenarios + sloppy fixture app
  tests/                   unit tests for every script
```

## Contributing

Open an issue with a real failure: the prompt, the model, what the agent did, what it should have done. Changes to the skill should come with an eval scenario or a lint test that fails before and passes after.

License: Apache-2.0.
